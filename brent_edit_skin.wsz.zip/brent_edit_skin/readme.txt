AOL Instant Messanger Amp (AIM Amp)	
(c) 2000 Neil Harvey
harveynj101@btinternet.com	
http://www.btinternet.com/~harveynj101/jonestown

A companion skin to go with the AOL instant Messanger program, my favourite method of chatting on the net.

A simple, clean skin done in a day 'cos was bored at work LOL

Version history

24-03-03
Upgraded to WA2.9 specification.
11-12-00
Added Text.bmp, fixed MikroAMP, skinned MB inner
14-09-00
Finished off with EQ sliders, cursors, and play list buttons.

13-09-00
Started skin, all windows done


"Use DeadAIM"